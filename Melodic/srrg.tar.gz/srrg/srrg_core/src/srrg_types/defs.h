#pragma once

#include <srrg_boss/eigen_boss_plugin.h>
#include "types.hpp"
