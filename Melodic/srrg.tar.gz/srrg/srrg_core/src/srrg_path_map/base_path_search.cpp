#include "base_path_search.h"

namespace srrg_core {
  
  BasePathSearch::BasePathSearch() {
    _output_path_map=0;
    _num_operations = 0;
  }

  BasePathSearch::~BasePathSearch() {
  }

  void BasePathSearch::init() {
  }

  void BasePathSearch::setup() {
  }

}
