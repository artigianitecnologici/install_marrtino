#include "counter.h"

// initialize counter 4 in 16 bit mode, to count at 0.5 us
void Counter_init(void){
}

uint16_t Counter_get(void){
  return 0;
}
