#include "eeprom.h"
void EEPROM_init(void){
}

void EEPROM_read(void* dest_, const uint16_t src, uint16_t size){
}

void EEPROM_write(uint16_t dest, const void* src_,  uint16_t size){
}
