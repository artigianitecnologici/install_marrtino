#pragma once
#include <stdint.h>

void delayMs(uint16_t ms);
